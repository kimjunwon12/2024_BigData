$(function () {
    $('.tabmenu>li>a').click(function () {
        $(this).parent().addClass('active')
            .siblings()
            .removeClass('active');
    });
});

$('.notice li:first').click(function(){
    $('#modal').addClass('active')

});
$('.bts').click(function(){
    $('#modal').removeClass('active')

});